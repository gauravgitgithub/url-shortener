<div class="flex items-center">
  <img src="https://lnk.ng/home/logo.png" style="width:40px;" />
  <span class="mx-2"><?php echo e(env('APP_NAME')); ?></span>
</div><?php /**PATH /var/www/html/url-shortener/resources/views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>