<?php return array (
  'analytics' => 'App\\Http\\Livewire\\Analytics',
  'create-link' => 'App\\Http\\Livewire\\CreateLink',
  'upgrade-user-plan-form' => 'App\\Http\\Livewire\\UpgradeUserPlanForm',
);