<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-center text-gray-800 leading-tight">
            <?php echo e(__('Welcome to ')); ?><?php echo e(env('APP_NAME')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
 
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-link')->html();
} elseif ($_instance->childHasBeenRendered('MUoErTH')) {
    $componentId = $_instance->getRenderedChildComponentId('MUoErTH');
    $componentTag = $_instance->getRenderedChildComponentTagName('MUoErTH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MUoErTH');
} else {
    $response = \Livewire\Livewire::mount('create-link');
    $html = $response->html();
    $_instance->logRenderedChild('MUoErTH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('analytics')->html();
} elseif ($_instance->childHasBeenRendered('WQB6ZQY')) {
    $componentId = $_instance->getRenderedChildComponentId('WQB6ZQY');
    $componentTag = $_instance->getRenderedChildComponentTagName('WQB6ZQY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WQB6ZQY');
} else {
    $response = \Livewire\Livewire::mount('analytics');
    $html = $response->html();
    $_instance->logRenderedChild('WQB6ZQY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /var/www/html/url-shortener/resources/views/dashboard.blade.php ENDPATH**/ ?>