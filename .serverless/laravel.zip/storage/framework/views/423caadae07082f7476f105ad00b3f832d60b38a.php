<div class="flex flex-col mt-6" wire:poll>
  <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
    <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
      <div class="shadow overflow-hidden border-b border-gray-200 bg-white sm:rounded-lg">
        <?php if($links->count()): ?>
            <table class="min-w-full divide-y divide-gray-200">
            <thead>
                <tr>
                <th class="px-6 py-3 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
                    Original URL
                </th>
                <th class="px-6 py-3 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
                    Short version
                </th>
                <th class="px-6 py-3 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
                    Views
                </th>
                <th class="px-6 py-3 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
                    For Single Use
                </th>
                <th class="px-6 py-3 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
                    Is Expired
                </th>
                <th class="px-6 py-3 bg-gray-50"></th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-no-wrap">
                            <?php echo e(substr($link->original, 0, 50)); ?><?php if(strlen($link->original) > 50): ?>...<?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-no-wrap">
                            <a href="<?php echo e(route('links.show', ['link' => $link->shortened])); ?>" target="__blank" class="px-2 inline-flex leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                <?php echo e(route('links.show', ['link' => $link->shortened])); ?>

                            </a>
                        </td>
                        <td class="px-6 py-4 whitespace-no-wrap">
                            <?php echo e(number_format($link->views)); ?>

                        </td>
                        <td class="px-6 py-4 whitespace-no-wrap">
                            <?php if($link->is_for_single_use_only == 1): ?>
                                <label style="color:orange;" >true</label>
                            <?php else: ?>
                                <label style="color:teal;" >false</label>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-no-wrap">
                            <?php if($link->is_expired == 1): ?>
                                <label style="color:red;" >true</label>
                            <?php else: ?>
                                <label style="color:green;" >false</label>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-no-wrap text-right text-sm leading-5 font-medium">
                            <button wire:click="deleteLink(<?php echo e($link->id); ?>)" class="text-red-500">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        <?php else: ?>
            <?php //NO LINKS CREATED 
            /*<p class="text-center p-4">No links found..</p>*/ ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?php /**PATH /var/www/html/url-shortener/resources/views/livewire/analytics.blade.php ENDPATH**/ ?>